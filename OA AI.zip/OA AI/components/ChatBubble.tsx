import React from 'react';
import ReactMarkdown from 'react-markdown';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Message, MessageRole, MessageType } from '../types';
import { User, Bot, Play } from 'lucide-react';

interface ChatBubbleProps {
  message: Message;
}

export const ChatBubble: React.FC<ChatBubbleProps> = ({ message }) => {
  const isUser = message.role === MessageRole.USER;
  const isSystem = message.role === MessageRole.SYSTEM;

  if (isSystem) return null;

  return (
    <div className={`flex w-full mb-6 ${isUser ? 'justify-start flex-row-reverse' : 'justify-start'}`}>
      {/* Avatar */}
      <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${isUser ? 'bg-indigo-600 ml-4' : 'bg-[#0EA5E9] mr-4'}`}>
        {isUser ? <User size={20} className="text-white" /> : <Bot size={20} className="text-white" />}
      </div>

      {/* Content */}
      <div className={`flex flex-col max-w-[85%] sm:max-w-[75%] ${isUser ? 'items-end' : 'items-start'}`}>
        <div className={`px-5 py-4 rounded-2xl ${
          isUser 
            ? 'bg-[#1f2937] text-white rounded-tr-none border border-gray-700' 
            : 'bg-gradient-to-br from-[#0f172a] to-[#1e293b] text-gray-100 rounded-tl-none border border-[#0EA5E9]/30 shadow-lg shadow-[#0EA5E9]/5'
        }`}>
          {/* Render based on Type */}
          
          {message.type === MessageType.TEXT && (
            <div className="prose prose-invert prose-sm max-w-none dir-rtl">
              <ReactMarkdown
                components={{
                  code({node, inline, className, children, ...props}: any) {
                    const match = /language-(\w+)/.exec(className || '')
                    return !inline && match ? (
                      <SyntaxHighlighter
                        {...props}
                        children={String(children).replace(/\n$/, '')}
                        style={vscDarkPlus}
                        language={match[1]}
                        PreTag="div"
                      />
                    ) : (
                      <code {...props} className={className}>
                        {children}
                      </code>
                    )
                  }
                }}
              >
                {message.content}
              </ReactMarkdown>
            </div>
          )}

          {message.type === MessageType.IMAGE && (
            <div className="space-y-2">
              <p className="text-sm text-gray-400 mb-2">تم إنشاء صورة:</p>
              <div className="relative group overflow-hidden rounded-lg border border-gray-700">
                <img 
                  src={message.content} 
                  alt="Generated Content" 
                  className="w-full h-auto max-h-[400px] object-cover"
                  loading="lazy"
                />
              </div>
            </div>
          )}

          {message.type === MessageType.AUDIO && (
            <div className="flex items-center gap-3 min-w-[250px]">
              <div className="p-2 bg-[#0EA5E9]/20 rounded-full text-[#0EA5E9]">
                <Play size={20} fill="currentColor" />
              </div>
              <audio controls src={message.content} className="w-full h-8" />
            </div>
          )}

          {message.metadata?.isProcessing && (
            <div className="flex items-center gap-2 mt-2 text-sky-400">
              <span className="animate-pulse">جاري المعالجة...</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};