import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Image as ImageIcon, 
  Mic, 
  Sparkles,
  MessageSquare,
  Bot
} from 'lucide-react';
import { Message, MessageRole, MessageType, AppMode } from './types';
import { generateTextResponse, generateImage, generateSpeech } from './services/geminiService';
import { ChatBubble } from './components/ChatBubble';

// Initial welcome message
const INITIAL_MESSAGE: Message = {
  id: 'init-1',
  role: MessageRole.MODEL,
  type: MessageType.TEXT,
  content: 'أهلاً بك. أنا OA AI، مساعدك الذكي المتطور. كيف يمكنني مساعدتك اليوم؟ (نصوص، صور، أو صوت)'
};

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([INITIAL_MESSAGE]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [mode, setMode] = useState<AppMode>(AppMode.CHAT);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!inputValue.trim() || isLoading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: MessageRole.USER,
      type: MessageType.TEXT,
      content: inputValue
    };

    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setIsLoading(true);

    try {
      let responseContent = '';
      let responseType = MessageType.TEXT;

      if (mode === AppMode.CHAT) {
        // Construct history for chat context
        const history = messages
          .filter(m => m.type === MessageType.TEXT) // Simplify history to text only for now
          .map(m => ({
            role: m.role === MessageRole.USER ? 'user' : 'model',
            parts: [{ text: m.content }]
          }));
        
        responseContent = await generateTextResponse(history, userMsg.content);
      
      } else if (mode === AppMode.IMAGE) {
        responseContent = await generateImage(userMsg.content);
        responseType = MessageType.IMAGE;
      
      } else if (mode === AppMode.TTS) {
        responseContent = await generateSpeech(userMsg.content);
        responseType = MessageType.AUDIO;
      }

      const botMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: MessageRole.MODEL,
        type: responseType,
        content: responseContent
      };

      setMessages(prev => [...prev, botMsg]);

    } catch (error: any) {
      console.error("Generation Error:", error);
      const errorMsg: Message = {
        id: Date.now().toString(),
        role: MessageRole.SYSTEM,
        type: MessageType.TEXT,
        content: `عذراً، حدث خطأ أثناء المعالجة: ${error.message || 'خطأ غير معروف'}`
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const ModeButton = ({ targetMode, icon: Icon, label }: { targetMode: AppMode, icon: any, label: string }) => (
    <button
      onClick={() => setMode(targetMode)}
      className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
        mode === targetMode 
          ? 'bg-[#0EA5E9] text-white' 
          : 'bg-gray-800 text-gray-400 hover:text-gray-200 hover:bg-gray-700'
      }`}
    >
      <Icon size={16} />
      <span>{label}</span>
    </button>
  );

  return (
    <div className="flex flex-col h-screen bg-[#111827] text-white font-sans overflow-hidden">
      
      {/* Header */}
      <header className="flex-shrink-0 border-b border-gray-800 bg-[#111827]/90 backdrop-blur-md z-10 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[#0EA5E9] rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(14,165,233,0.5)]">
            <Sparkles className="text-white" size={24} />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white">OA AI</h1>
            <p className="text-xs text-[#0EA5E9] font-medium">مساعد ذكي احترافي</p>
          </div>
        </div>
        
        {/* Mode Selector - Top Bar for Desktop */}
        <div className="hidden sm:flex items-center gap-2 bg-[#1f2937] p-1 rounded-full border border-gray-700">
          <ModeButton targetMode={AppMode.CHAT} icon={MessageSquare} label="محادثة" />
          <ModeButton targetMode={AppMode.IMAGE} icon={ImageIcon} label="صور" />
          <ModeButton targetMode={AppMode.TTS} icon={Mic} label="صوت" />
        </div>
      </header>

      {/* Main Chat Area */}
      <main className="flex-1 overflow-y-auto p-4 sm:p-6 scroll-smooth">
        <div className="max-w-3xl mx-auto space-y-6">
          {messages.map((msg) => (
            <ChatBubble key={msg.id} message={msg} />
          ))}
          {isLoading && (
            <div className="flex w-full justify-start">
               <div className="flex-shrink-0 w-10 h-10 bg-[#0EA5E9] rounded-full flex items-center justify-center mr-4">
                 <Bot size={20} className="text-white animate-pulse" />
               </div>
               <div className="bg-[#1e293b] px-5 py-4 rounded-2xl rounded-tl-none border border-[#0EA5E9]/30">
                 <div className="flex space-x-2 space-x-reverse">
                   <div className="w-2 h-2 bg-[#0EA5E9] rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                   <div className="w-2 h-2 bg-[#0EA5E9] rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                   <div className="w-2 h-2 bg-[#0EA5E9] rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                 </div>
               </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Input Area */}
      <footer className="flex-shrink-0 p-4 bg-[#111827] border-t border-gray-800">
        <div className="max-w-3xl mx-auto">
          {/* Mobile Mode Selector */}
          <div className="sm:hidden flex justify-between mb-4 overflow-x-auto pb-2 gap-2">
            <ModeButton targetMode={AppMode.CHAT} icon={MessageSquare} label="محادثة" />
            <ModeButton targetMode={AppMode.IMAGE} icon={ImageIcon} label="صور" />
            <ModeButton targetMode={AppMode.TTS} icon={Mic} label="صوت" />
          </div>

          <form onSubmit={handleSubmit} className="relative flex items-end gap-2 bg-[#1f2937] p-2 rounded-2xl border border-gray-700 shadow-xl focus-within:border-[#0EA5E9] focus-within:ring-1 focus-within:ring-[#0EA5E9] transition-all">
            <textarea
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSubmit();
                }
              }}
              placeholder={
                mode === AppMode.CHAT ? "اكتب رسالتك هنا..." :
                mode === AppMode.IMAGE ? "وصف الصورة التي تريد توليدها..." :
                "النص الذي تريد تحويله لصوت..."
              }
              className="w-full bg-transparent border-0 text-white placeholder-gray-500 focus:ring-0 resize-none py-3 px-3 max-h-32 min-h-[50px] scrollbar-hide"
              rows={1}
            />
            
            <button
              type="submit"
              disabled={!inputValue.trim() || isLoading}
              className="p-3 bg-[#0EA5E9] text-white rounded-xl hover:bg-[#0284c7] disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg shadow-sky-500/20 mb-0.5"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <Send size={20} className={document.dir === 'rtl' ? 'rotate-180' : ''} />
              )}
            </button>
          </form>
          <div className="text-center mt-2">
             <p className="text-[10px] text-gray-600">
               {mode === AppMode.CHAT && "Gemini 2.5 Flash"}
               {mode === AppMode.IMAGE && "Gemini 2.5 Flash Image"}
               {mode === AppMode.TTS && "Gemini 2.5 TTS"}
             </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;