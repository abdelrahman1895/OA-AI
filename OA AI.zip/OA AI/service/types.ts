// Global types

export enum MessageRole {
  USER = 'user',
  MODEL = 'model',
  SYSTEM = 'system'
}

export enum MessageType {
  TEXT = 'text',
  IMAGE = 'image',
  AUDIO = 'audio'
}

export interface Message {
  id: string;
  role: MessageRole;
  type: MessageType;
  content: string; // Text content or URL for media
  metadata?: {
    mimeType?: string;
    altText?: string;
    isProcessing?: boolean;
  };
}

export enum AppMode {
  CHAT = 'chat',
  IMAGE = 'image',
  TTS = 'tts'
}

// Veo / AI Studio Window augmentation
declare global {
  interface Window {
    webkitAudioContext: typeof AudioContext;
  }
}