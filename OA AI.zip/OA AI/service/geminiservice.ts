import { GoogleGenAI, Modality } from "@google/genai";
import { OA_AI_SYSTEM_INSTRUCTION } from "../constants";

// Helper to get a client. 
// Note: For Veo, we re-instantiate to ensure we catch the fresh key if selected via UI.
const getClient = () => {
  // Assuming process.env.API_KEY is available as per instructions.
  const apiKey = process.env.API_KEY || ''; 
  return new GoogleGenAI({ apiKey });
};

// Text Generation
export const generateTextResponse = async (history: { role: string; parts: { text: string }[] }[], newMessage: string) => {
  const ai = getClient();
  const chat = ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: OA_AI_SYSTEM_INSTRUCTION,
    },
    history: history,
  });

  const response = await chat.sendMessage({ message: newMessage });
  return response.text;
};

// Image Generation
export const generateImage = async (prompt: string) => {
  const ai = getClient();
  // Using nano banana series for general image generation as per guidelines
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        { text: prompt }
      ]
    },
    config: {
      imageConfig: {
        aspectRatio: "1:1",
      }
    }
  });

  // Extract image from parts
  if (response.candidates?.[0]?.content?.parts) {
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData && part.inlineData.data) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
  }
  throw new Error("No image data found in response");
};

// Speech Generation (TTS)
export const generateSpeech = async (text: string): Promise<string> => {
  const ai = getClient();
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: text }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Zephyr' }, // Options: Puck, Charon, Kore, Fenrir, Zephyr
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) throw new Error("No audio data returned");

  return `data:audio/wav;base64,${base64Audio}`; // Assuming WAV or raw PCM wrapper is handled by browser/model defaults often map to playable types
};

// Helper for audio decoding if raw PCM (Advanced usage, but for simple playback we try base64 src first. 
// If specific PCM decoding is needed, we would use the Context method).
// Given standard browser <audio> tag behavior, base64 src usually works if container is correct. 
// Gemini TTS usually returns raw PCM or WAV container. Let's assume standard handling or use AudioContext if needed.